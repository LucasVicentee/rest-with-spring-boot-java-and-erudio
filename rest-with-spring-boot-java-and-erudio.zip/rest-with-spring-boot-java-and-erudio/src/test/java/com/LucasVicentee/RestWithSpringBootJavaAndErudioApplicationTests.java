package com.LucasVicentee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestWithSpringBootJavaAndErudioApplicationTests {

	@Test
	void contextLoads() {
	}

}
